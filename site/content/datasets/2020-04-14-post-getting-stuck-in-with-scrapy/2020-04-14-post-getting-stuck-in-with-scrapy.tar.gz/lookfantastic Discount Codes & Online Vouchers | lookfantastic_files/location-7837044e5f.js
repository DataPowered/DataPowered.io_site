"use strict";define("$location",function(){return window.location});
//# sourceMappingURL=location-7837044e5f.js.map
