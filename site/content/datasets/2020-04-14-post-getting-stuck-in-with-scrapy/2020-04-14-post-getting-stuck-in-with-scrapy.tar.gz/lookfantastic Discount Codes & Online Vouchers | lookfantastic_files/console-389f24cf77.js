"use strict";define("$console",function(){return window.console});
//# sourceMappingURL=console-389f24cf77.js.map
