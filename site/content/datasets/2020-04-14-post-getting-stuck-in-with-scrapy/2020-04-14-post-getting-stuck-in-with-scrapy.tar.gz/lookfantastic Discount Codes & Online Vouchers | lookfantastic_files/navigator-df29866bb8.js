"use strict";define("$navigator",function(){return navigator});
//# sourceMappingURL=navigator-df29866bb8.js.map
