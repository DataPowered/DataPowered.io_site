"use strict";define([],function(){var n;return function n(t,e,u){var r,i,a,l,o,c=Date.now||function(){return(new Date).getTime()},f=function n(){var f=c()-l;f<e&&f>0?r=setTimeout(n,e-f):(r=null,u||(o=t.apply(a,i),r||(a=i=null)))};return function(){a=this,i=arguments,l=c();var n=u&&!r;return r||(r=setTimeout(f,e)),n&&(o=t.apply(a,i),a=i=null),o}}});
//# sourceMappingURL=debounce-2b7d1b5628.js.map
