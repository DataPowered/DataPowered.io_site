"use strict";define("$window",function(){return window});
//# sourceMappingURL=window-b5411aa072.js.map
