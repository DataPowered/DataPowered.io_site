"use strict";define([],function(){var e;return{columboVersion:"2.2",chaseSessionKey:"chumewe_sess",chaseUserKey:"chumewe_user",gtmEventNameAppend:"_Columbo",filterAtts:["data-context","data-component","data-component-tracked-viewed","data-component-tracked-clicked","class","data-widget-id"]}});
//# sourceMappingURL=columbo-constants-91c698676e.js.map
